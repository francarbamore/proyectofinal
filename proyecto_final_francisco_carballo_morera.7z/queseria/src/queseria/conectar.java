
package queseria;

import java.sql.Connection;
import java.sql.DriverManager;


public class conectar {
    
    Connection conectar = null;
    public Connection conexion(){
        
        try{
            Class.forName("com.mysql.jdbc.Driver");
            conectar=DriverManager.getConnection("jdbc:mysql://localhost:3306/queseria?useSSL=false","root","penilo2010");
        }catch(Exception e){
         
            System.out.printf(e.getMessage());
        }
        return conectar;
    }
            
}
