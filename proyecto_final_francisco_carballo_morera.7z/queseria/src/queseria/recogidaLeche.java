/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package queseria;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import static javafx.beans.binding.Bindings.length;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

/**
 *
 * @author usuario
 */
public class recogidaLeche extends javax.swing.JFrame {

  
    
/**
 * Constructor de la clase que inicializa los métodos initComponents() -- " Método que carga todos los
 * objetos que hallamos puesto en el JFrame-- JPanel al momento de ejecutar la aplicación, por ello van 
 * dentro del constructor de la clase. "
 * El método mostrarDatos() " Que muestra la JTable 'tbganaderos' con los datos de la tabla 'recogidaleche' ", y 
 * el método comboGanaderos() " Que rellena los Items del combobox 'cbganaderos' con el 'nombre', 'apellido1',
 * 'apellido2' y el 'nif' de los ganaderos de la tabla 'ganaderos' de la base de datos"
 */   
    public recogidaLeche() {
        initComponents();
        mostrarDatos("");
        comboGanaderos();
         
    }
/**
 * Este método se va a encargar de presentar la JTable 'tbganaderos' con los datos de la tabla 'recogidaleche'
 * de la base de datos.
 * Se le pasa un parametro de tipo String llamdo valor.
 * Este atributo 'valor' se va a encargar de recoger los datos que le envian por un lado el botón del formulario
 * 'Mostrar datos' --> que le envía siempre un caracter vacío, esto hace que la sentencia 'if' ejecute un 
 * "SELECT * FROM recogidaleche", mostrandonos todos los datos de la tabla 'recogidaleche' de la base de datos, en
 * JTable 'tbganaderos' y por otro lado el botón 'Buscar' le envía el nif de un ganadero, que hace que la sentencia 
 * 'if' ejecute un "SELECT * FROM recogidaleche WHERE nif='" + valor + "'", realizando una busqueda por 
 * el valor del nif en la tabla 'recogidaleche' de la base de datos.
 * 
 * @param valor 
 */
    
    void mostrarDatos(String valor) {
/**
 * DefaultTableModel es una clase que implementa TableModel que contiene todos los métodos necesarios para
 * modificar datos en su interior, añadir filas o columnas y darle a cada columna el nombre que se desee. 
 * Para utilizar DefaultTableModel debemos importarla y luego declararla para luego poder usar la clase JTable.
 */
        DefaultTableModel modelo = new DefaultTableModel();
 /**
  * Añadimos las cabeceras de las columnas de la tabla
  */       
        modelo.addColumn("CODIGO");
        modelo.addColumn("NOMBRE ");
        modelo.addColumn("DIA");
        modelo.addColumn("MES");
        modelo.addColumn("AÑO");
        modelo.addColumn("LITROS");
/**
 * Mostramos la tabla
 */
        tbganaderos.setModel(modelo);

        String sql = "";

        if (valor.equals("")) {
            sql = "SELECT * FROM recogidaleche";
        } else {

            sql = "SELECT * FROM recogidaleche WHERE nif='" + valor + "'";
        }
        TableColumn columna;
        String[] datos = new String[11];
        try {

            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(4);
                datos[4] = rs.getString(5);
                datos[5] = rs.getString(6);

                modelo.addRow(datos);

            }

           // tbganaderos.setModel(modelo);
           // mostramos la tabla
            tbganaderos.setModel(modelo);

        // LES DAMOS UN TAMAÑO ADECUADO A CADA COLUMNA
            //la columnna CODIGO
            columna = tbganaderos.getColumnModel().getColumn(0);
            columna.setPreferredWidth(75);
            columna.setMaxWidth(75);
            columna.setMinWidth(75);
            //la columnna NOMBRE
            columna = tbganaderos.getColumnModel().getColumn(1);
            columna.setPreferredWidth(175);
            columna.setMaxWidth(175);
            columna.setMinWidth(175);
            //la columnna DIA
            columna = tbganaderos.getColumnModel().getColumn(2);
            columna.setPreferredWidth(75);
            columna.setMaxWidth(75);
            columna.setMinWidth(75);
            //la columnna MES
            columna = tbganaderos.getColumnModel().getColumn(3);
            columna.setPreferredWidth(75);
            columna.setMaxWidth(75);
            columna.setMinWidth(75);
            //la columnna AÑO
            columna = tbganaderos.getColumnModel().getColumn(4);
            columna.setPreferredWidth(75);
            columna.setMaxWidth(75);
            columna.setMinWidth(75);
            //la columnna CANTIDAD DE LECHE
            columna = tbganaderos.getColumnModel().getColumn(5);
            columna.setPreferredWidth(120);
            columna.setMaxWidth(120);
            columna.setMinWidth(120);

        } catch (SQLException ex) {
            Logger.getLogger(recogidaLeche.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    conectar c = new conectar();
    Connection cn = c.conexion();

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPopupMenu1 = new javax.swing.JPopupMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        nifganadero = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        anno = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        litros = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        mes = new javax.swing.JTextField();
        dia = new javax.swing.JTextField();
        btgrabar = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JSeparator();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbganaderos = new javax.swing.JTable();
        txtbuscar = new javax.swing.JTextField();
        txtboton = new javax.swing.JButton();
        txtmostrar = new javax.swing.JButton();
        btactualizar = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        btlimpiarformulario = new javax.swing.JButton();
        cbganaderos = new javax.swing.JComboBox();
        codigorecogida = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jMenuItem1.setText("modificar");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jPopupMenu1.add(jMenuItem1);

        jMenuItem2.setText("eliminar");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jPopupMenu1.add(jMenuItem2);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Recogida de la leche");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Datos ganaderos"));
        jPanel1.setName(""); // NOI18N

        jLabel2.setText("DIA");

        jLabel5.setText("NIF/DNI");

        jLabel3.setText("MES");

        jLabel7.setText("LITROS");

        litros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                litrosActionPerformed(evt);
            }
        });

        jLabel4.setText("AÑO");

        btgrabar.setText("Grabar");
        btgrabar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btgrabarActionPerformed(evt);
            }
        });

        tbganaderos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        tbganaderos.setComponentPopupMenu(jPopupMenu1);
        jScrollPane2.setViewportView(tbganaderos);

        txtbuscar.setColumns(9);
        txtbuscar.setName(""); // NOI18N
        txtbuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtbuscarActionPerformed(evt);
            }
        });

        txtboton.setText("Buscar");
        txtboton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtbotonActionPerformed(evt);
            }
        });

        txtmostrar.setText("Mostrar datos");
        txtmostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtmostrarActionPerformed(evt);
            }
        });

        btactualizar.setText("Actualizar");
        btactualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btactualizarActionPerformed(evt);
            }
        });

        jLabel13.setText("Busca por el nif");

        btlimpiarformulario.setText("Limpiar Formulario");
        btlimpiarformulario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btlimpiarformularioActionPerformed(evt);
            }
        });

        cbganaderos.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbganaderos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbganaderosActionPerformed(evt);
            }
        });

        codigorecogida.setEditable(false);
        codigorecogida.setBackground(new java.awt.Color(255, 255, 255));
        codigorecogida.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel1.setText("Codigo");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(txtbuscar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtboton)
                        .addGap(26, 26, 26)
                        .addComponent(txtmostrar))
                    .addComponent(jLabel13)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btgrabar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btactualizar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btlimpiarformulario))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4)
                        .addGap(34, 34, 34)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(nifganadero, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbganaderos, javax.swing.GroupLayout.PREFERRED_SIZE, 338, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(dia, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(mes, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(anno, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(litros, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(codigorecogida, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 60, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 599, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(206, 206, 206)
                .addComponent(jSeparator2, javax.swing.GroupLayout.DEFAULT_SIZE, 195, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(cbganaderos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23)
                        .addComponent(jLabel1)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(105, 105, 105)
                                .addComponent(jLabel7))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(codigorecogida, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(13, 13, 13)
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(1, 1, 1)
                                .addComponent(nifganadero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4))))
                        .addGap(1, 1, 1)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(dia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(mes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(anno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(litros, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(42, 42, 42)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btgrabar)
                            .addComponent(btactualizar)
                            .addComponent(btlimpiarformulario))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(txtboton)
                                .addComponent(txtmostrar))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel13)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtbuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 545, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(1060, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(83, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel1.getAccessibleContext().setAccessibleName("Recogida de la leche");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btgrabarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btgrabarActionPerformed

        /**
         * con esta instruccion cogemos el nif del ganadero que hemos elegido en
         * la lista combo int posicion =this.cbganaderos.getSelectedIndex(); el
         * 3 es la posicion de la columna de la fila elegida en el combo String
         * nift= ganaderos[posicion][3];
         * nifganadero.setText(nifganadero.getText()+nift);
         */
        /**
         *
         *
         */
        String diat = dia.getText();
        String mest = mes.getText();
        String annot = anno.getText();

        try {

            conectar c = new conectar();
            Connection cn = c.conexion();
            PreparedStatement pst = cn.prepareStatement("INSERT INTO recogidaleche(nif,dia,mes,anno,"
                    + "cantidad) VALUES(?,?,?,?,?)");

            //pst.setString(1, nifganadero.getText());
            pst.setString(1, nifganadero.getText());
            pst.setInt(2, Integer.parseInt(diat));
            pst.setInt(3, Integer.parseInt(mest));
            pst.setInt(4, Integer.parseInt(annot));
            pst.setInt(5, Integer.parseInt(litros.getText()));

            pst.executeUpdate();
            mostrarDatos("");
            pst.close();
            cn.close();
        } catch (Exception e) {

        } finally {
            /**
             * estas instrucciones nos sirve para cuando damos de alta varias
             * recogida de la leche seguida nos pone el mismo dia, mes y año que
             * la anterior recogida, para no tener que volver a teclearla
             */
            dia.setText(diat);
            mes.setText(mest);
            anno.setText(annot);
            // en el campo del formulario nif de ganadero y litros de leche pone cadena vacía
            nifganadero.setText("");
            litros.setText("");

        }
    }//GEN-LAST:event_btgrabarActionPerformed
// muestra los datos por el nif, que es el campo que hemos puesto por defecto
    private void txtbotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtbotonActionPerformed

        mostrarDatos(txtbuscar.getText());

    }//GEN-LAST:event_txtbotonActionPerformed

    private void txtmostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtmostrarActionPerformed
        mostrarDatos("");
    }//GEN-LAST:event_txtmostrarActionPerformed

    // este menu emergente lo usamos para cuando querramos modificar una fila de la tabla ganaderos
    // no tengamos que rellenar todos los campos del formulario de nuevo, sino que escogiendo
    //una fila de la tabla ganaderos y pulsando el boton derecho del raton sale este menu con la opcion
    //modificar trasladando los datos de esa fila a los campos del menu
    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        int[] fila = tbganaderos.getSelectedRows();
        if (fila[0] >= 0) {
            codigorecogida.setText(tbganaderos.getValueAt(fila[0], 0).toString());
            dia.setText(tbganaderos.getValueAt(fila[0], 2).toString());
            mes.setText(tbganaderos.getValueAt(fila[0], 3).toString());
            anno.setText(tbganaderos.getValueAt(fila[0], 4).toString());
            nifganadero.setText(tbganaderos.getValueAt(fila[0], 1).toString());
            litros.setText(tbganaderos.getValueAt(fila[0], 5).toString());

        } else {
            JOptionPane.showMessageDialog(null, "no se seleccione ninguna fila");
        }

    }//GEN-LAST:event_jMenuItem1ActionPerformed
// esta función es la encargada de realizar las actualizaciones
    private void btactualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btactualizarActionPerformed

        try {
        
            PreparedStatement pst = cn.prepareStatement("UPDATE recogidaleche SET idrecogidaleche='" + Integer.parseInt(codigorecogida.getText()) + "',nif='"
                    + nifganadero.getText() + "',dia='" + Integer.parseInt(dia.getText()) + "',mes='" + Integer.parseInt(mes.getText()) + "',anno='"
                    + Integer.parseInt(anno.getText()) + "',cantidad='" + Integer.parseInt(litros.getText()) + "' WHERE  idrecogidaleche='"
                    + Integer.parseInt(codigorecogida.getText()) + "'");
            
           
            
            pst.executeUpdate();
            mostrarDatos("");
        } catch (Exception e) {
            System.out.printf(e.getMessage());
        }
    }//GEN-LAST:event_btactualizarActionPerformed
// metodo que se encarga de eliminar las filas de la tabla recogidaleche
    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        // TODO add your handling code here:
        int fila = tbganaderos.getSelectedRow();
        int id = 0;
        String nif = "";
        id = Integer.parseInt(tbganaderos.getValueAt(fila, 0).toString());
        try {
            PreparedStatement pst = cn.prepareStatement("DELETE FROM recogidaleche WHERE idrecogidaleche=" + id);
            pst.executeUpdate();
            mostrarDatos("");
        } catch (Exception e) {
            System.out.printf(e.getMessage());
        }
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void txtbuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtbuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtbuscarActionPerformed
/**
 * Es método lo utilizamos con el botón limpiar formulario para dejar todos los campos del
 * formulario en blanco.
 * @param evt 
 */
    private void btlimpiarformularioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btlimpiarformularioActionPerformed

        codigorecogida.setText("");
        dia.setText("");
        mes.setText("");
        anno.setText("");
        nifganadero.setText("");
        litros.setText("");


    }//GEN-LAST:event_btlimpiarformularioActionPerformed

    private void litrosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_litrosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_litrosActionPerformed
    private void comboGanaderos() {
        
   /**
 * El array tipo String ganaderos, (Es una array de 30 filas por 4 columnas) va a contener los ganaderos 
 * que cargamos desde la base de datos, en concreto de la tabla ganadero de la cual solo nos interesa 
 * el nombre, apellido1, apellido2 y el nif, porque este array solo lo vamos a utilizar para rellenar 
 * los items del combobox cbganaderos.
 * Solo tiene 30 filas porque la quesería donde va a estar este programa siempre ha tenido entre 4 y 12 
 * ganaderos, pero para queserias más grandes lo ideal sería poner un arrayList o algo parecido.
 * Eso será para la próxima versión. :)
 *  
 * Este array lo vamos a utilizar en el método  private void comboGanaderos()
 */
     
        String[][] ganaderos = new String[30][4];
        
        String sql = "";
        //String [][] ganaderos = new String [20][4];
        int indice = 0;
        // vamos a conectar con la base de datos queseria y obtener de la tabla ganaderos los nombres de los ganaderos para 
        // pasar lo a la lista del  combobox
        sql = "SELECT * FROM ganaderos";
        try {
            // con esta instruccion eliminar los Items  que vienen por defecto en el combobox   
            this.cbganaderos.removeAllItems();
            // hacemos la conexion a la base de datos
            conectar c = new conectar();
            Connection cn = c.conexion();

            // le pasamos la instruccion SQL A LA BASE DE DATOS donde leeremos los nombres y los nif de los ganaderos
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            // la variable indice nos va a ir recorriendo el vector nombresGanaderos a medida que los vamos descargando de la base de datos
            // y guardando en el vector.
            // la variable indice tanbien nos va a dar el numero de ganaderos

            // mientras haya ganaderos los vamos insetando en el combobox
            while (rs.next()) {
                this.cbganaderos.addItem(rs.getString("nombre") + "  " + rs.getString("apellido1") + "  " + rs.getString("apellido2") + "  " + rs.getString("nif"));
                // recogemos los nombres y los nif para despues pasarlos a la tabla donde nos mostrará los litros de leche
                ganaderos[indice][0] = rs.getString("nombre");
                ganaderos[indice][1] = rs.getString("apellido1");
                ganaderos[indice][2] = rs.getString("apellido2");
                ganaderos[indice++][3] = rs.getString("nif");
            }
            /**
             * con esta instruccion cogemos el nif del ganadero que hemos
             * elegido en la lista combo y lo colocamos en el campo del
             * formulario que pertenece al nif
             *
             */

            //posicion = this.cbganaderos.getSelectedIndex();
         // el 3 es la posicion de la columna de la fila elegida en el combo
            //String nift;
          //  nift = ganaderos[posicion][3];
          //  nifganadero.setText(nift);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    /**
     * Este método se ejecuta cuando utilizamos el combobox donde tenemos la lista de los ganaderos dados
     * de alta en la queseria.
     * @param evt 
     */
    private void cbganaderosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbganaderosActionPerformed

        //JOptionPane.showMessageDialog(null,this.cbganaderos.getSelectedItem());
  /**
   * El atributo delimitadores se le va a pasar como parametro al método split para que nos separe
   * la cadena que le pasamos, en un array con las distintas partes de esa cadena, según el dilimitador 
   * o delimitadores que le pasemos. En este cado le pasamos un espacio en blanco.
   */      
        String delimitadores = " ";
 /**
  * El atributo nif es declarado como un array de cadenas por que lo vamos a usar con el
  * método split que nos devuelve cada palabra de la cadena que le pasamos según los delimitadores
  * que le pasemos.
  */       
        String[] nif;
  /**
   * El atributo ultimo lo vamos a usar por que nuestra pretención es obtener el nif del
   * ganadero que contiene la cadena que nos devuelve el combobox y el nif siempre va a ser la
   * ultima palabra de la cadena.
   * Se podria pensar que como el nif del ganadero es el cuarto campo o la cuarta palabra de esa cadena
   * también podriamos coger el nif en la cuarta posicion que nos devuelve el método split, pero nos puede dar 
   * problemas con los nombres y apellidos compuestos por mas de una palabra, con lo que ya el nif no
   * estaría en la cuarta posición.
   */      
        int ultimo=0;
 /** El atributo cadena va a contener los datos del item que elegimos en el combobox de los ganaderos.
  *  En concreto va a contener el nombre, los dos apellidos y el nif
  */       
  /**
   * Como veras hemos tenido que realizar un castin "(String)" a lo que nos devuelve el método getSelectedItem()
   * por que este método nos devuelve un objeto.
   */
        String cadena = (String) cbganaderos.getSelectedItem();
  /**
   * Esta condición la hemos puesto porque el combobox le devuelve al string cadena un valor null
   * antes de devolverle el nombre, los apellidos y el nif y por tanto le estariamos pasando al método split
   * un valor nulo, dando como resultado un error
   */      
        if(cadena!=null) {
              nif = cadena.split(delimitadores);
  /**
   * Obtenemos la longitud del array de cadenas, es decir cuantas palabras hay en la cadena devuelta separadas
   * por espacios en blanco
   */
              ultimo=nif.length;
  /**
   * Como la primera posición de un array la obtenmos empezando por cero, el nif del ganadero
   * estará en la posición ultimo-1
   */           
  /**
   * Por último pasamos el nif del ganadero al TextField(campo de texto) nifganadero del formulario
   * y al TextField txtbuscar que lo utilizamos para realizar busquedas por el nif.
   */
              nifganadero.setText(nif[ultimo-1]);
              txtbuscar.setText(nif[ultimo-1]);
        }
    }//GEN-LAST:event_cbganaderosActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField anno;
    private javax.swing.JButton btactualizar;
    private javax.swing.JButton btgrabar;
    private javax.swing.JButton btlimpiarformulario;
    private javax.swing.JComboBox cbganaderos;
    private javax.swing.JTextField codigorecogida;
    private javax.swing.JTextField dia;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField litros;
    private javax.swing.JTextField mes;
    private javax.swing.JTextField nifganadero;
    private javax.swing.JTable tbganaderos;
    private javax.swing.JButton txtboton;
    private javax.swing.JTextField txtbuscar;
    private javax.swing.JButton txtmostrar;
    // End of variables declaration//GEN-END:variables

    // iniciamos la conexion a la base de datos.
  
    
}
