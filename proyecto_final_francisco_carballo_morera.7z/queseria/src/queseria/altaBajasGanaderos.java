/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package queseria;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author usuario
 */
public class altaBajasGanaderos extends javax.swing.JFrame {
   

    /**
     * Creates new form altaBajasGanaderos
     */
    public altaBajasGanaderos() {
        initComponents();
        mostrarDatos("");
    }
    
    // este metodo nos va a mostrar los datos de los ganaderos que tenemos en la tabla ganaderos
    // mediante el atributo valor vamos a ir pasando el nif de los ganaderos que vamos a mostrar o el
    // valor vacio para que nos muestre a todos los ganaderos
    void mostrarDatos(String valor){
        
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("CODIGO");
        modelo.addColumn("NOMBRE ");
        modelo.addColumn("APELLIDO1");
        modelo.addColumn("APELLIDO2");
        modelo.addColumn("NIF");
        modelo.addColumn("GRANJA");
        modelo.addColumn("DIRECCION");
        modelo.addColumn("TELFONO");
        modelo.addColumn("FORMA PAGO");
        modelo.addColumn("ALTA");
        modelo.addColumn("COOPERATIVA");
        tbganaderos.setModel(modelo);
        
        String sql="";
       
        if(valor.equals(""))
        {
            sql="SELECT * FROM ganaderos";
        }
        else{
            
             sql="SELECT * FROM ganaderos WHERE nif='"+valor+"'";
             }
        
        String []datos= new String[11];
        try {
            
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
                datos[0]=rs.getString(1);
                datos[1]=rs.getString(2);
                datos[2]=rs.getString(3);
                datos[3]=rs.getString(4);
                datos[4]=rs.getString(5);
                datos[5]=rs.getString(6);
                datos[6]=rs.getString(7);
                datos[7]=rs.getString(8);
                datos[8]=rs.getString(9);
                datos[9]=rs.getString(10);
                datos[10]=rs.getString(11);
                modelo.addRow(datos);
                         
            }
            
            tbganaderos.setModel(modelo);
        } catch (SQLException ex) {
            Logger.getLogger(altaBajasGanaderos.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
     conectar c= new conectar();
     Connection cn= c.conexion();
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPopupMenu1 = new javax.swing.JPopupMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        codigoganadero = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        nifganadero = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        apellido2ganadero = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        granjaganadero = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        direccionganadero = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        apellido1ganadero = new javax.swing.JTextField();
        nombreganadero = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        telefonoganadero = new javax.swing.JTextField();
        btgrabar = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        formapago = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        cooperativa = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbganaderos = new javax.swing.JTable();
        txtbuscar = new javax.swing.JTextField();
        txtboton = new javax.swing.JButton();
        txtmostrar = new javax.swing.JButton();
        btactualizar = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        btlimpiarformulario = new javax.swing.JButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jMenuItem1.setText("modificar");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jPopupMenu1.add(jMenuItem1);

        jMenuItem2.setText("eliminar");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jPopupMenu1.add(jMenuItem2);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Altas - Bajas Ganaderos");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Datos ganaderos"));
        jPanel1.setName(""); // NOI18N

        jLabel1.setText("Codigo");

        jLabel2.setText("Nombre");

        jLabel5.setText("NIF/DNI");

        jLabel3.setText("Apellido1");

        jLabel7.setText("Nº de granja");

        jLabel6.setText("Dirección");

        jLabel8.setText("Telefono");

        jLabel4.setText("Apellido2");

        jLabel9.setText("cooperativa");

        btgrabar.setText("Grabar");
        btgrabar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btgrabarActionPerformed(evt);
            }
        });

        jLabel10.setText("S/N");

        jLabel11.setText("Forma de pago");

        jLabel12.setText("Q/M");

        tbganaderos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        tbganaderos.setComponentPopupMenu(jPopupMenu1);
        jScrollPane2.setViewportView(tbganaderos);

        txtbuscar.setColumns(9);
        txtbuscar.setName(""); // NOI18N
        txtbuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtbuscarActionPerformed(evt);
            }
        });

        txtboton.setText("Buscar");
        txtboton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtbotonActionPerformed(evt);
            }
        });

        txtmostrar.setText("Mostrar datos");
        txtmostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtmostrarActionPerformed(evt);
            }
        });

        btactualizar.setText("Actualizar");
        btactualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btactualizarActionPerformed(evt);
            }
        });

        jLabel13.setText("Busca por el nif");

        btlimpiarformulario.setText("Limpiar Formulario");
        btlimpiarformulario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btlimpiarformularioActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator2)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel11)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel12)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(formapago, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(36, 36, 36)
                                        .addComponent(jLabel9))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel1)
                                            .addComponent(jLabel5))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(codigoganadero, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(73, 73, 73))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                                .addComponent(nifganadero, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel2)
                                            .addComponent(jLabel8))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                                    .addGap(49, 49, 49)
                                                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(cooperativa, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addComponent(nombreganadero, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                    .addComponent(jLabel3)))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(telefonoganadero, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(apellido1ganadero, javax.swing.GroupLayout.DEFAULT_SIZE, 106, Short.MAX_VALUE)
                                    .addComponent(granjaganadero))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(apellido2ganadero, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 463, Short.MAX_VALUE))
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addContainerGap())
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(direccionganadero, javax.swing.GroupLayout.PREFERRED_SIZE, 527, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btgrabar)
                                .addGap(41, 41, 41)
                                .addComponent(btlimpiarformulario)
                                .addGap(43, 43, 43)
                                .addComponent(btactualizar))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(txtbuscar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtboton)
                                .addGap(33, 33, 33)
                                .addComponent(txtmostrar))
                            .addComponent(jLabel13))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(codigoganadero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(apellido2ganadero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(apellido1ganadero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(nombreganadero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(granjaganadero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(telefonoganadero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel5)
                    .addComponent(nifganadero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(formapago, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10)
                    .addComponent(cooperativa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(direccionganadero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btgrabar)
                    .addComponent(btlimpiarformulario)
                    .addComponent(btactualizar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21)
                .addComponent(jLabel13)
                .addGap(1, 1, 1)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtbuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtboton)
                    .addComponent(txtmostrar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(395, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btgrabarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btgrabarActionPerformed
       try{ 
           conectar c= new conectar();
        Connection cn=c.conexion();
       /* PreparedStatement pst = cn.prepareStatement("INSERT INTO ganaderos(idganaderos,nombre,apellido1,apellido2,nif,"
                + "granja,direccion,telefono,formapago,alta,cooperativa) VALUES(?,?,?,?,?,?,?,?,?,?,?)");*/
        PreparedStatement pst = cn.prepareStatement("INSERT INTO ganaderos(nombre,apellido1,apellido2,nif,"
                + "granja,direccion,telefono,formapago,alta,cooperativa) VALUES(?,?,?,?,?,?,?,?,?,?)");
        //pst.setInt(1, Integer.parseInt(codigoganadero.getText()));
        pst.setString(1, nombreganadero.getText());
        pst.setString(2, apellido1ganadero.getText());
        pst.setString(3, apellido2ganadero.getText());
        pst.setString(4, nifganadero.getText());
        pst.setString(5, granjaganadero.getText());
        pst.setString(6, direccionganadero.getText());
        pst.setString(7, telefonoganadero.getText());
        pst.setString(8, formapago.getText());
        pst.setString(9, "S");
        pst.setString(10,cooperativa.getText());
        
        
        pst.executeUpdate();
        mostrarDatos("");
        pst.close();
        cn.close();
       }catch(Exception e){
           
       }finally{
           //codigoganadero.setText("");
        nombreganadero.setText("");
        apellido1ganadero.setText("");
        apellido2ganadero.setText("");
        nifganadero.setText("");
        granjaganadero.setText("");
        direccionganadero.setText("");
        telefonoganadero.setText("");
        formapago.setText("");
        cooperativa.setText("");
       }
    }//GEN-LAST:event_btgrabarActionPerformed
// muestra los datos por el nif, que es el campo que hemos puesto por defecto
    private void txtbotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtbotonActionPerformed
       
       
        mostrarDatos(txtbuscar.getText());
       
    }//GEN-LAST:event_txtbotonActionPerformed

    private void txtmostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtmostrarActionPerformed
       mostrarDatos("");
    }//GEN-LAST:event_txtmostrarActionPerformed

    // este menu emergente lo usamos para cuando querramos modificar una fila de la tabla ganaderos
    // no tengamos que rellenar todos los campos del formulario de nuevo, sino que escogiendo
    //una fila de la tabla ganaderos y pulsando el boton derecho del raton sale este menu con la opcion
    //modificar trasladando los datos de esa fila a los campos del menu
    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        int[] fila = tbganaderos.getSelectedRows();
     if(fila[0]>=0){
        codigoganadero.setText(tbganaderos.getValueAt(fila[0],0).toString());
        nombreganadero.setText(tbganaderos.getValueAt(fila[0],1).toString());
        apellido1ganadero.setText(tbganaderos.getValueAt(fila[0],2).toString());
        apellido2ganadero.setText(tbganaderos.getValueAt(fila[0],3).toString());
        nifganadero.setText(tbganaderos.getValueAt(fila[0],4).toString());
        granjaganadero.setText(tbganaderos.getValueAt(fila[0],5).toString());
        direccionganadero.setText(tbganaderos.getValueAt(fila[0],6).toString());
        telefonoganadero.setText(tbganaderos.getValueAt(fila[0],7).toString());
        formapago.setText(tbganaderos.getValueAt(fila[0],8).toString());
        cooperativa.setText(tbganaderos.getValueAt(fila[0],10).toString());
        
     }else{
         JOptionPane.showMessageDialog(null,"no se seleccione ninguna fila");
     }
     
    }//GEN-LAST:event_jMenuItem1ActionPerformed
// esta función es la encargada de realizar las actualizaciones
    private void btactualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btactualizarActionPerformed
     // idganaderos='"+codigoganadero.getText()+"',
        try{
        PreparedStatement pst = cn.prepareStatement("UPDATE ganaderos SET idganaderos='"+codigoganadero.getText()+"',nombre='"+
          nombreganadero.getText()+"',apellido1='"+apellido1ganadero.getText()+"',apellido2='"+apellido2ganadero.getText()+"',nif='"+
          nifganadero.getText()+"',granja='"+granjaganadero.getText()+"',direccion='"+direccionganadero.getText()+"',telefono='"+
                telefonoganadero.getText()+"',formapago='"+formapago.getText()+"',alta='"+cooperativa.getText()+"' WHERE  idganaderos='"+
                codigoganadero.getText()+"'");
        
        pst.executeUpdate();
        mostrarDatos("");
        }catch(Exception e)
        {
            System.out.printf(e.getMessage());
        }
    }//GEN-LAST:event_btactualizarActionPerformed
// metodo que se encarga de eliminar las filas de la tabla ganaderos
    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        // TODO add your handling code here:
        int fila = tbganaderos.getSelectedRow();
        String nif="";
        nif=tbganaderos.getValueAt(fila,4).toString();
        try{
        PreparedStatement pst = cn.prepareStatement("DELETE FROM ganaderos WHERE nif='"+nif+"'");
        pst.executeUpdate();
        mostrarDatos("");
        }catch(Exception e){
             System.out.printf(e.getMessage());
        }
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void txtbuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtbuscarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtbuscarActionPerformed

    private void btlimpiarformularioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btlimpiarformularioActionPerformed
        
       //  codigoganadero.setText("");
        nombreganadero.setText("");
        apellido1ganadero.setText("");
        apellido2ganadero.setText("");
        nifganadero.setText("");
        granjaganadero.setText("");
        direccionganadero.setText("");
        telefonoganadero.setText("");
        formapago.setText("");
        cooperativa.setText("");
         
    }//GEN-LAST:event_btlimpiarformularioActionPerformed

  
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField apellido1ganadero;
    private javax.swing.JTextField apellido2ganadero;
    private javax.swing.JButton btactualizar;
    private javax.swing.JButton btgrabar;
    private javax.swing.JButton btlimpiarformulario;
    private javax.swing.JTextField codigoganadero;
    private javax.swing.JTextField cooperativa;
    private javax.swing.JTextField direccionganadero;
    private javax.swing.JTextField formapago;
    private javax.swing.JTextField granjaganadero;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField nifganadero;
    private javax.swing.JTextField nombreganadero;
    private javax.swing.JTable tbganaderos;
    private javax.swing.JTextField telefonoganadero;
    private javax.swing.JButton txtboton;
    private javax.swing.JTextField txtbuscar;
    private javax.swing.JButton txtmostrar;
    // End of variables declaration//GEN-END:variables

    // iniciamos la conexion a la base de datos.
    
   

}
